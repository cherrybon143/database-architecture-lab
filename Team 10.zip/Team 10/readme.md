from flask import Flask, request, jsonify
from flask_cors import CORS
from database import db, init_db

app = Flask(__name__)
CORS(app)
init_db(app)

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    price = db.Column(db.Float, nullable=False)
    stock = db.Column(db.Integer, nullable=False)

@app.route("/products", methods=["GET"])
def get_products():
    products = Product.query.all()
    return jsonify([{"id": p.id, "name": p.name, "price": p.price, "stock": p.stock} for p in products])

@app.route("/add_product", methods=["POST"])
def add_product():
    data = request.json
    new_product = Product(name=data["name"], price=data["price"], stock=data["stock"])
    db.session.add(new_product)
    db.session.commit()
    return jsonify({"message": "Product added successfully!"})

if __name__ == "__main__":
    app.run(debug=True)
